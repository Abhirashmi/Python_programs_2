import random

random_number = random.randint(0, 1)
# print(random_number)
rand = random.random() * 100
# print(rand)
lst = ["Star Plus", "DD1", "Aaj Tak", "CodeWithHarry","abhirashmi","colours tv"]
choice = random.choice(lst)
print(choice)

