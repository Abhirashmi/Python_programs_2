# l=[["abhi",9],["uuu",75878],["abhirashmi",79],["fghcjyhcjhcfuuu",8],["c gnv nbvn",99]]
#
# for item ,iii in l:
#     print(item,"and lolly is ",iii)
l1=[5,8,988,5,6,6,"hugujggkgk",45,345,6,7,8,9,76,0,2,1,3,5,4,3,11,22,33,44,7,8,99,678,6678,87665567888]
for items in l1:
    if str(items).isnumeric() and items>=6:
        print("the items is greator than 6 :",items)
    elif items==6:
        print("the item is equal to 6 :",items)
    elif type(items)==str:
        print("this item is of type string   :",items)
    else:
        print("this item is less than 6 :",items)
print("ok bye !!")

