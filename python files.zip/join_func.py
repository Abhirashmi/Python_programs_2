ls=["abhi","rashmi","mithhu ","pk","john","piku","dasssss "]

a=",".join(ls)
print(a,"and others ")