class Library:
    def __init__(self,list,name):
        self.booklist=list
        self.name=name
        self.lendDict={}

    def display_book(self):
        print(f"We have following books in our Library {self.name}")
        for book in self.booklist:
            print(book)

    def Lend_book(self,name,book):
        if book not in self.lendDict.keys():
            self.lendDict.update({book:name})
            print(f"lender book data-base has been updated. you can take te book now  ")

        elif book in self.lendDict.keys():
            print(f"the {book} book is with {self.lendDict[book]} ")

        else:
            print("Sorry we don't have"+book+"in our Library ")

    def Add_book(self,book):
       if book in self.booklist:
        print("we have the book and hence we don't need this one !!")

       else:
        self.booklist.append(book)
        print(" book has been added to the library successfully ")

    def Return_book(self,book):
        self.Lend_book.pop(book)

if __name__ == '__main__':
    abhirashmi=Library(['python ', 'c ','c++','dsa ','dbms','os'],'Abhirashmi_ki_library ')
    while(True):
        print(f"WELCOME TO THE LIBRARY {abhirashmi.name} .Enter your choice to continue")
        print("1.Display books")
        print("2.lend a book")
        print("3.Add a  books")
        print("4.Return a books")

        user_choice=int(input( ))

        if user_choice == 1:
            abhirashmi.display_book()

        elif user_choice == 2:
            abhirashmi.display_book()
            user = input("Enter your name ")
            book=input("Enter the book which you want to borrow from our library ?")
            abhirashmi.Lend_book(user,book)

        elif user_choice == 3:
            book=input("Enter the name of the  book you want to add ? ")
            abhirashmi.Add_book(book)

        elif user_choice == 4:
            book=input("Enter the name of the book you want to return ?")
            abhirashmi.Return_book(book)

        else:
            print("Not a valid option ")

        print("  PRESS 'q' to QUIT and 'c' to CONTINUE   ")
        user_choice2=input()

        if user_choice2 == 'q':
            quit()

        elif user_choice2 == 'c':
            continue

        else:
            print("NOT A VALID OPTION ")






# Create a library class
# display book
# lend book - (who owns the book if not present)
# add book
# return book

# HarryLibrary = Library(listofbooks, library_name)


#dictionary (books-nameofperson)

# create a main function and run an infinite while loop asking
# users for their input


class Library:
    def __init__(self, list, name):
        self.booksList = list
        self.name = name
        self.lendDict = {}

    def displayBooks(self):
        print(f"We have following books in our library: {self.name}")
        for book in self.booksList:
            print(book)

    def lendBook(self, user, book):
        if book not in self.lendDict.keys():
            self.lendDict.update({book:user})
            print("Lender-Book database has been updated. You can take the book now")
        else:
            print(f"Book is already being used by {self.lendDict[book]}")

    def addBook(self, book):
        self.booksList.append(book)
        print("Book has been added to the book list")

    def returnBook(self, book):
        self.lendDict.pop(book)

if __name__ == '__main__':
    harry = Library(['Python', 'Rich Daddy Poor Daddy', 'Harry Potter', 'C++ Basics', 'Algorithms by CLRS'], "CodeWithHarry")

    while(True):
        print(f"Welcome to the {harry.name} library. Enter your choice to continue")
        print("1. Display Books")
        print("2. Lend a Book")
        print("3. Add a Book")
        print("4. Return a Book")
        user_choice = input()
        if user_choice not in ['1','2','3','4']:
            print("Please enter a valid option")
            continue

        else:
            user_choice = int(user_choice)


        if user_choice == 1:
            harry.displayBooks()

        elif user_choice == 2:
            book = input("Enter the name of the book you want to lend:")
            user = input("Enter your name")
            harry.lendBook(user, book)

        elif user_choice == 3:
            book = input("Enter the name of the book you want to add:")
            harry.addBook(book)

        elif user_choice == 4:
            book = input("Enter the name of the book you want to return:")
            harry.returnBook(book)

        else:
            print("Not a valid option")


        print("Press q to quit and c to continue")
        user_choice2 = ""
        while(user_choice2!="c" and user_choice2!="q"):
            user_choice2 = input()
            if user_choice2 == "q":
                exit()

            elif user_choice2 == "c":
                continue


# Create a library class
# display book
# lend book - (who owns the book if not present)
# add book
# return book

# HarryLibrary = Library(listofbooks, library_name)


#dictionary (books-nameofperson)

# create a main function and run an infinite while loop asking
# users for their input


class Library:
    def __init__(self, list, name):
        self.booksList = list
        self.name = name
        self.lendDict = {}

    def displayBooks(self):
        print(f"We have following books in our library: {self.name}")
        for book in self.booksList:
            print(book)

    def lendBook(self, user, book):
        if book not in self.lendDict.keys():
            self.lendDict.update({book:user})
            print("Lender-Book database has been updated. You can take the book now")
        else:
            print(f"Book is already being used by {self.lendDict[book]}")

    def addBook(self, book):
        self.booksList.append(book)
        print("Book has been added to the book list")

    def returnBook(self, book):
        self.lendDict.pop(book)

if __name__ == '__main__':
    harry = Library(['Python', 'Rich Daddy Poor Daddy', 'Harry Potter', 'C++ Basics', 'Algorithms by CLRS'], "CodeWithHarry")

    while(True):
        print(f"Welcome to the {harry.name} library. Enter your choice to continue")
        print("1. Display Books")
        print("2. Lend a Book")
        print("3. Add a Book")
        print("4. Return a Book")
        user_choice = input()
        if user_choice not in ['1','2','3','4']:
            print("Please enter a valid option")
            continue

        else:
            user_choice = int(user_choice)


        if user_choice == 1:
            harry.displayBooks()

        elif user_choice == 2:
            book = input("Enter the name of the book you want to lend:")
            user = input("Enter your name")
            harry.lendBook(user, book)

        elif user_choice == 3:
            book = input("Enter the name of the book you want to add:")
            harry.addBook(book)

        elif user_choice == 4:
            book = input("Enter the name of the book you want to return:")
            harry.returnBook(book)

        else:
            print("Not a valid option")


        print("Press q to quit and c to continue")
        user_choice2 = ""
        while(user_choice2!="c" and user_choice2!="q"):
            user_choice2 = input()
            if user_choice2 == "q":
                exit()

            elif user_choice2 == "c":
                continue

